No app binary was supplied for this local package.
