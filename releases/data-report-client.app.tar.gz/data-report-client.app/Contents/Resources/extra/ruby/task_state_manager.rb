require "json"
require "tmpdir"
require "fileutils"
require "pp"
require "fastlane_core"

class TaskStateManager
  def initialize(tmp_dir)
    @tmp_dir = tmp_dir
    @state_file = File.join(@tmp_dir, "results.json")
    FileUtils.mkdir_p(@tmp_dir) unless Dir.exist?(@tmp_dir)

    pp "使用tmpDir：#{tmp_dir}"
  end

  # 检查是否需要执行该应用，返回true为处理，false为不处理
  def should_process_app?(bundle_id)
    state = load_state

    # 规则1：如果状态为nil（首次执行），那么必须执行所有应用
    return true if state.nil? || expired?(state["last_execution"])

    # 查找应用状态
    app_state = state["apps"].find { |app| app["bundle_id"] == bundle_id }
    return true unless app_state # 如果找不到应用记录，执行该应用

    # 如果应用未成功，需要重新执行
    !app_state["success"]
  end

  # 检查是否需要执行该任务
  def should_process_task?(bundle_id, task)
    # 返回true为执行，返回false为跳过
    state = load_state

    # 规则1和2：如果状态为nil（首次执行）或如果超过24小时，必须执行所有任务，必须执行所有任务
    return true if state.nil? || expired?(state["last_execution"])

    # 查找应用状态
    app_state = state["apps"].find { |app| app["bundle_id"] == bundle_id }
    return true unless app_state # 如果找不到应用记录，执行所有任务

    # 查找任务状态
    task_state = app_state["tasks"].find { |t| t["task"] == task.to_s }
    return true unless task_state # 如果找不到任务记录，执行该任务

    # 如果任务失败，需要重新执行
    !task_state["success"]
  end

  # 检查是否需要执行子任务，返回true为执行，返回false为跳过
  def should_process_subtask?(bundle_id, task, subtask_key, subtask_value)
    state = load_state

    # 规则1和2：如果状态为nil（首次执行），必须执行所有任务
    return true if state.nil? || expired?(state["last_execution"])

    app_state = state["apps"].find { |app| app["bundle_id"] == bundle_id }
    return true unless app_state # 如果找不到应用记录，执行所有任务

    task_state = app_state["tasks"].find { |t| t["task"] == task.to_s }
    return true unless task_state

    # 不再需要根据整个任务成功状态来决定是否跳过子任务
    # return false if task_state["success"]

    subtasks = task_state["subtasks"] || []
    subtask = subtasks.find { |st| st["key"] == subtask_key && st["value"] == subtask_value }

    subtask.nil? || !subtask["success"]
  end

  def update_app_state(bundle_id, app_name)
    state = load_state || create_new_state

    app_state = state["apps"].find { |app| app["bundle_id"] == bundle_id }
    unless app_state
      app_state = {
        "bundle_id" => bundle_id,
        "app_name" => app_name,
        "success" => false,
        "tasks" => [],
      }
      state["apps"] << app_state
    end

    # 更新执行时间并保存
    state["last_execution"] = Time.now.iso8601
    save_state(state)
  end

  # 添加人物状态并更新成功状态
  def update_task_state(bundle_id, app_name, task, task_name, task_success, subtask = nil)
    state = load_state || create_new_state

    app_state = state["apps"].find { |app| app["bundle_id"] == bundle_id }
    unless app_state
      app_state = {
        "bundle_id" => bundle_id,
        "app_name" => app_name,
        "success" => false,
        "tasks" => [],
      }
      state["apps"] << app_state
    end

    # 查找或创建任务状态
    task_state = app_state["tasks"].find { |t| t["task"] == task.to_s }
    if task_state
      task_state["success"] = task_success
    else
      # 如果没有任务则创建任务
      task_state = {
        "task" => task.to_s,
        "task_name" => task_name,
        "success" => task_success,
        "subtasks" => [],
      }
      app_state["tasks"] << task_state
    end

    if subtask
      # 更新子任务状态
      subtask_state = task_state["subtasks"].find { |st|
        st["key"] == subtask[:key] && st["value"] == subtask[:value]
      }

      if subtask_state
        subtask_state["success"] = subtask[:success]
      else
        task_state["subtasks"] << {
          "key" => subtask[:key],
          "value" => subtask[:value],
          "success" => subtask[:success],
        }
      end
    end

    # 更新执行时间并保存
    state["last_execution"] = Time.now.iso8601
    save_state(state)
  end

  # 标记应用完成的状态
  def mark_app_success(bundle_id)
    state = load_state
    return unless state

    app_state = state["apps"].find { |app| app["bundle_id"] == bundle_id }
    return unless app_state

    app_state["success"] = app_state["tasks"].all? { |t| t["success"] }

    save_state(state)
  end

  def mark_task_success(bundle_id, task, task_success = nil)
    state = load_state
    return unless state

    app_state = state["apps"].find { |app| app["bundle_id"] == bundle_id }
    return unless app_state

    task_state = app_state["tasks"].find { |t| t["task"] == task.to_s }
    return unless task_state

    # 是否存在子任务
    if task_state["subtasks"].empty?
      # 不存在子任务
      task_state["success"] = task_success
    else
      # 存在子任务，那么需要判断
      # 根据所有子任务状态判断是否成功
      task_state["success"] = task_state["subtasks"].all? { |st| st["success"] }
    end

    save_state(state)
  end

  def clear_state
    File.delete(@state_file) if File.exist?(@state_file)
  end

  def has_failed_app
    state = load_state

    return unless state

    state["apps"].find { |app| !app["success"] }
  end

  private

  def load_state
    return nil unless File.exist?(@state_file)
    begin
      JSON.parse(File.read(@state_file))
    rescue JSON::ParserError => e
      FastlaneCore::UI.error("读取状态文件失败：#{e.message}")
      nil
    end
  end

  def save_state(state)
    begin
      File.write(@state_file, JSON.pretty_generate(state))
    rescue StandardError => e
      FastlaneCore::UI.error("保存状态文件失败: #{e.message}")
    end
  end

  def create_new_state
    {
      "last_execution" => Time.now.iso8601,
      "apps" => [],
    }
  end

  def expired?(last_execution)
    return true if last_execution.nil?
    Time.now - Time.parse(last_execution) > 24 * 60 * 60
  end
end
