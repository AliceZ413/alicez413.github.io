# ruby resources/script/fetch-analytics-prod.rb [config_path]
require "net/http"
require "uri"
require "json"
require "pp"
require "spaceship"
require "faraday"
require "fastlane_core"
require_relative "./shared-values.rb"
require_relative "./upload_service.rb"
require_relative "./task_state_manager.rb"

# 获取命令行参数
tmp_json_path = ARGV[0]
start_date = ARGV[1]
end_date = ARGV[2]

###
# app_measure_interval_extend
# 销量 iap
# 销售额 sales
#
# 展示次数 impressionsTotal
# 展示次数（独立设备）impressionsTotalUnique
# 产品页面查看次数 pageViewCount
# 产品页面查看次数（独立设备） pageViewUnique
# 下载总数 totalDownloads
# 首次下载 units
###

# @measure_types_list = [
#   "impressionsTotal",
#   "impressionsTotalUnique",
#   "pageViewCount",
#   "pageViewUnique",
#   "totalDownloads",
#   "units",
#   "activeDevices",
# ]
# @measure_types = {
#   "impressionsTotal" => "impressions",
#   "impressionsTotalUnique" => "impressions_unique_devices",
#   "pageViewCount" => "page_views",
#   "pageViewUnique" => "page_views_unique_devices",
#   "totalDownloads" => "downloads_total",
#   "units" => "downloads_first_time",
#   "activeDevices" => "active_devices",
# }
# @category_genre_map = {
#   "BUSINESS" => 6000,
#   "WEATHER" => 6001,
#   "UTILITIES" => 6002,
#   "TRAVEL" => 6003,
#   "SPORTS" => 6004,
#   "SOCIAL_NETWORKING" => 6005,
#   "REFERENCE" => 6006,
#   "PRODUCTIVITY" => 6007,
#   "PHOTO_AND_VIDEO" => 6008,
#   "NEWS" => 6009,
#   "NAVIGATION" => 6010,
#   "MUSIC" => 6011,
#   "LIFESTYLE" => 6012,
#   "HEALTH_AND_FITNESS" => 6013,
#   "GAMES" => 6014,
#   "FINANCE" => 6015,
#   "ENTERTAINMENT" => 6016,
#   "EDUCATION" => 6017,
#   "BOOKS" => 6018,
#   "MEDICAL" => 6020,
#   "MAGAZINES_AND_NEWSPAPERS" => 6021,
#   "FOOD_AND_DRINK" => 6023,
#   "SHOPPING" => 6024,
#   "STICKERS" => 6025,
#   "DEVELOPER_TOOLS" => 6026,
#   "GRAPHICS_AND_DESIGN" => 6027,
# }
# @random_regions = SharedValues::get_random_regions(4)

# # 获取genre_id
# def map_genre_id_from_category(category)
#   return nil if category.empty?
#   @category_genre_map[category] || nil
# end

# # 获取三周前的周一
# def get_three_weeks_ago(date)
#   original_date = Date.strptime(date, "%FT00:00:00Z")
#   three_weeks_ago = original_date - 21
#   monday_of_three_weeks_ago = three_weeks_ago - three_weeks_ago.wday + 1
#   monday_of_three_weeks_ago.strftime("%FT00:00:00Z")
# end

# # 获取App分析数据
# def get_from_app_analytics(analytics, start_date, end_date, measure, dimension_filters, view_by)
#   response = analytics.app_measure_interval_extend(start_date, end_date, measure, dimension_filters, view_by)
#   results = response["results"]
#   if results
#     result = results
#   else
#     result = []
#   end
# end

# # 获取留存率
# def get_retention(analytics, start_date, end_date)
#   response = analytics.app_retention_interval(start_date, end_date)
#   results = response["results"]
#   if results
#     result = []
#     for itm in results
#       data = itm["data"]
#       result.push(data[1])
#     end
#     result
#   else
#     result = []
#   end
# end

# # 获取dimension_values
# def get_dimension_values(analytics, end_date)
#   response = analytics.dimension_values(
#     "2015-04-01T00:00:00Z", # 固定
#     end_date,
#     ["benchCrashRate", "benchRetentionD1", "benchRetentionD7", "benchRetentionD28", "benchConversionRate", "benchArppu"],
#     "week",
#     [],
#     []
#   )
#   results = response["results"]
#   if results
#     result = results[0]["values"]
#   else
#     result = []
#   end
#   result
# end

# # 获取primary_genre_id
# def get_primary_genre_id(connect_api_app)
#   return nil if connect_api_app.fetch_live_app_info.nil? || connect_api_app.fetch_live_app_info.primary_category.nil?
#   primary_category = Spaceship::ConnectAPI::AppCategory.map_category_from_itc(connect_api_app.fetch_live_app_info.primary_category.id)
#   map_genre_id_from_category(primary_category)
# end

# # 获取app primary_genre_id
# def get_app_primary_genre_id(app, end_date)
#   app_id = app.apple_id

#   result = fetch_app_version(app_id, "US")

#   if result.length == 0
#     @random_regions.each { |region|
#       result = fetch_app_version(app_id, region)
#       if !result.nil?
#         break
#       end
#     }
#   end

#   if result.length == 0
#     FastlaneCore::UI.error("无法获取应用(#{app_id})的version")
#   else
#     three_weeks_ago = get_three_weeks_ago(end_date)
#     # 时间降序
#     genre_id = nil
#     result.sort { |a, b|
#       b[:release_time] <=> a[:release_time]
#     }.each { |item|
#       if is_newer(three_weeks_ago, item[:release_time])
#         genre_id = item[:genre_id]
#         break
#       end
#     }
#     genre_id
#   end
# end

# # 请求genre id
# def fetch_app_version(app_id, region)
#   uri = URI("http://proxies.flowever.net/1.1/qimai/version")
#   params = { :country => region, :appid => app_id }
#   uri.query = URI.encode_www_form(params)
#   result = []

#   Net::HTTP.start(uri.host, uri.port) do |http|
#     req = Net::HTTP::Get.new(uri, "Content-Type" => "application/json;charset=utf-8;")
#     res = http.request(req)

#     json = JSON.parse(res.body.force_encoding("UTF-8"))
#     if json&.[]("result")&.[]("version").nil?
#       result
#     else
#       result = json["result"]["version"]
#     end
#   end
#   result.map { |e|
#     {
#       release_time: parse_chinese_date(e["release_time"]),
#       genre_id: e["genre_id"],
#       genre_name: e["genre_name"],
#     }
#   }
# end

# def parse_chinese_date(chinese_date_str)
#   # 使用正则表达式提取日期和时间部分
#   match = chinese_date_str.match(/(\d{4})年(\d{2})月(\d{2})日/)
#   if match
#     year = match[1].to_i
#     month = match[2].to_i
#     day = match[3].to_i

#     # 创建时间对象
#     Date.new(year, month, day).strftime("%FT00:00:00Z")
#   else
#     raise ArgumentError, "日期格式不正确"
#   end
# end

# # 对比时间
# def is_newer(date_1, date_2)
#   original_date_1 = Date.strptime(date_1, "%FT00:00:00Z")
#   original_date_2 = Date.strptime(date_2, "%FT00:00:00Z")
#   original_date_1 > original_date_2
# end

# # 上传营收数据
# def upload_proceeds(app, tunes, connect_api_app, apple_account, apple_account_name, start_date, end_date)
#   apple_id = app.apple_id
#   data = []

#   if connect_api_app.get_live_app_store_version.nil?
#     # 非live_version时，为空值
#     data = []
#   else
#     analytics = app.analytics
#     response = analytics.app_measure_interval(start_date, end_date, "proceeds")
#     results = response["results"]
#     iaps = tunes.iaps(app_id: app.apple_id)
#     if iaps.length > 0
#       if results
#         result = results[0]
#         data = result["data"]
#       else
#         # 拿不到analytics数据时，为空值
#         data = []
#       end
#     else
#       # 没有内购项时，为空值
#       data = []
#     end

#     uri = URI("http://datareport.softinkit.com/dashboard/proceeds/log/v2")
#     Net::HTTP.start(uri.host, uri.port) do |http|
#       req = Net::HTTP::Post.new(uri, "Content-Type" => "application/json")
#       req.body = {
#         "channel_type": "App Store",
#         "apple_account": apple_account,
#         "apple_account_name": apple_account_name,
#         "app_id": apple_id,
#         "data": data,
#       }.to_json
#       res = http.request(req)
#     end
#   end
# end

# # 上传App分析数据
# def upload_app_analytics(app, start_date, end_date)
#   apple_id = app.apple_id
#   analytics = app.analytics
#   app_analytics_data = []
#   for measure_types in @measure_types_list
#     data = get_from_app_analytics(analytics, start_date, end_date, measure_types, [], "storefront")
#     for itm in data
#       region_code = itm["group"]["key"]
#       region_name = itm["group"]["title"]
#       analytics_data = itm["data"]

#       exist = app_analytics_data.find { |i| i["region_code"] == region_code }

#       if exist == nil
#         obj = {
#           "region_code" => region_code,
#           "region_name" => region_name,
#           "analytics_data" => analytics_data,
#         }
#         app_analytics_data.push obj
#       else
#         # 用于合并的哈希表
#         merged_data = merge_array analytics_data, exist["analytics_data"]
#         exist["analytics_data"] = merged_data
#       end
#     end
#   end
#   uri = URI("http://datareport.softinkit.com/dashboard/app-analytics/log")
#   Net::HTTP.start(uri.host, uri.port) do |http|
#     req = Net::HTTP::Post.new(uri, "Content-Type" => "application/json")
#     req.body = {
#       "app_id": apple_id,
#       "data": app_analytics_data,
#     }.to_json
#     res = http.request(req)
#   end
# end

# # 上传活跃设备和次日留存率
# def upload_retention(app, start_date, end_date)
#   apple_id = app.apple_id
#   analytics = app.analytics
#   data = get_retention(analytics, start_date, end_date)
#   # TODO 使用不同接口？
#   uri = URI("http://datareport.softinkit.com/dashboard/app-analytics/retention/log")
#   Net::HTTP.start(uri.host, uri.port) do |http|
#     req = Net::HTTP::Post.new(uri, "Content-Type" => "application/json")
#     req.body = {
#       "app_id": apple_id,
#       "data": data,
#     }.to_json
#     res = http.request(req)
#   end
# end

# # 上传基准数据
# def upload_benchmarks(app, connect_api_app, apple_account, start_date, end_date)
#   FastlaneCore::Helper.show_loading_indicator("上报基准数据")
#   apple_id = app.apple_id
#   analytics = app.analytics

#   # 日期处理
#   # 开始日期和结束日期为end_date的三周前的周一
#   date = get_three_weeks_ago(end_date)

#   genre_id = get_app_primary_genre_id(app, end_date)
#   if !genre_id.nil?
#     dimension_values = get_dimension_values(analytics, end_date)
#     peerGroupIds = dimension_values.select { |e|
#       e["size"] == "ALL" && e["category"] == "GENRE_#{genre_id}"
#     }.map { |e|
#       e["id"]
#     }

#     res_1 = analytics.app_measure_interval_v2(
#       date,
#       date,
#       ["benchCrashRate", "benchRetentionD1", "benchRetentionD7", "benchRetentionD28", "benchConversionRate", "benchArppu"],
#       "week",
#       [{ dimensionKey: "peerGroupId", optionKeys: peerGroupIds }]
#     )
#     peer_group_benchmark = res_1&.[]("results")&.[](0)&.[]("data")&.[](0)

#     # 应用基准数据
#     res_2 = analytics.app_measure_interval_v2(
#       date,
#       date,
#       ["crashRate", "retentionD1", "retentionD7", "retentionD28", "conversionRate", "arppu"],
#       "week",
#       []
#     )
#     app_benchmark = res_2&.[]("results")&.[](0)&.[]("data")&.[](0)

#     if !peer_group_benchmark.nil? && !app_benchmark.nil?
#       request_body = {
#         app_id: apple_id,
#         apple_account: apple_account,
#         date: date,
#         benchmarks: [
#           {
#             genre_id: genre_id,
#             app: app_benchmark,
#             peer_group_benchmark: peer_group_benchmark,
#           },
#         ],
#       }

#       uri = URI("http://datareport.softinkit.com/dashboard/peer-group-benchmark/report")
#       Net::HTTP.start(uri.host, uri.port) do |http|
#         req = Net::HTTP::Post.new(uri, "Content-Type" => "application/json")
#         req.body = request_body.to_json
#         res = http.request(req)
#       end
#     end
#   end
#   FastlaneCore::Helper.hide_loading_indicator
# end

# # 合并数据
# def merge_array(array1, array2)
#   # 用于存储合并后的数据
#   @array1 = array1.clone
#   @array2 = array2.clone

#   $i = 0
#   $array_length = @array1.length
#   begin
#     @array1[$i].merge! @array2[$i]
#     $i += 1
#   rescue => exception
#     raise exception
#   end while $i <= $array_length - 1

#   @array1
# end

# 默认配置
$app_analytics_dataset_sources = ["Search"]
$app_analytics_dataset_devices = ["iPhone", "iPad"]
$app_analytics_dataset_regions = ["143441", "143465", "143462", "143466"]

# App分析数据集 上传
def get_app_analytics_dataset_config
  begin
    uri = URI("http://datareport.softinkit.com/dashboard/app-analytics-dataset/config")

    Net::HTTP.start(uri.host, uri.port) do |http|
      req = Net::HTTP::Get.new(uri, "Content-Type" => "application/json;charset=utf-8;")
      res = http.request(req)

      json = JSON.parse(res.body.force_encoding("UTF-8"))
      $app_analytics_dataset_sources = json&.[]("sources") || $app_analytics_dataset_sources
      $app_analytics_dataset_devices = json&.[]("devices") || $app_analytics_dataset_devices
      $app_analytics_dataset_regions = json&.[]("regions") || $app_analytics_dataset_regions
    end
  rescue => e
    puts "请求配置错误，将使用默认配置"
  end
end

def main(apple_account, apple_account_pwd, apple_account_name, start_date, end_date)
  # tunes登录
  tunes = Spaceship::Tunes.login(apple_account, apple_account_pwd)
  FastlaneCore::UI.message("登录成功")
  apps = Spaceship::Tunes::Application.all

  # 使用系统
  tmp_dir = File.join(Dir.tmpdir, "app_analytics_tasks")
  task_manager = TaskStateManager.new(tmp_dir)

  # 定义所有需要执行的任务
  upload_tasks = [
    # 新的数据获取
    # [:upload_app_analytics_dataset_source, "数据集-来源"], # 数据集-来源
    # [:upload_app_analytics_dataset_device, "数据集-设备"], # 数据集-设备
    # [:upload_app_analytics_dataset_retention, "数据集-留存率"],

    [:upload_proceeds, "营收数据"],
    [:upload_app_analytics, "应用分析数据"],
    [:upload_retention, "留存率数据"],
    [:upload_benchmarks, "基准数据"],
  ]

  # 获取远程App分析数据集配置
  get_app_analytics_dataset_config

  FastlaneCore::UI.message("====== 开始，共#{apps.size}个应用")
  # 使用最新的App List
  apps.each_with_index do |app, index|
    FastlaneCore::UI.message("------ #{index + 1}. #{app.name} 开始")

    unless task_manager.should_process_app?(app.bundle_id)
      FastlaneCore::UI.message("跳过应用：#{app.name}")
      next
    end

    connect_api_app = Spaceship::ConnectAPI::App.find(app.bundle_id)

    if connect_api_app
      # 记录错误的任务
      current_failed_tasks = []

      upload_service = UploadService.new(
        app,
        tunes,
        connect_api_app,
        apple_account,
        apple_account_name,
        start_date,
        end_date,
        task_manager,
        current_failed_tasks,
        $app_analytics_dataset_sources,
        $app_analytics_dataset_devices,
        $app_analytics_dataset_regions,
      )

      upload_tasks.each do |task, task_name|
        unless task_manager.should_process_task?(app.bundle_id, task)
          FastlaneCore::UI.message("跳过任务：#{task_name}")
          next
        end

        begin
          upload_service.send(task)
        rescue => error # StandardError
          puts "\n"
          FastlaneCore::UI.error("#{task_name}上报失败: #{error.message}")
        end
      end

      # 执行完当前应用的所有任务后，更新应用状态
      task_manager.mark_app_success(app["bundle_id"])

      FastlaneCore::UI.message("------ #{index + 1}. #{app.name} 结束")
    else
      FastlaneCore::UI.error("无法通过Bundle_ID：#{app.bundle_id}，找到应用")
    end
  end
end

if tmp_json_path && start_date && end_date
  json = File.read(tmp_json_path)
  obj = JSON.parse(json)

  apple_account_name = obj["apple_account_name"]
  apple_account = obj["apple_account"]
  password = obj["password"]
  if apple_account_name && apple_account && password
    main(apple_account, password, apple_account_name, start_date, end_date)
  else
    puts "找不到账号!"
  end
else
  puts "请检查参数！"
end
