# ruby resources/script/fetch-analytics-prod.rb [config_path]
require "net/http"
require "uri"
require "json"
require "pp"
require "spaceship"
require "faraday"
require "fastlane_core"
require_relative "./shared-values.rb"
require_relative "./upload_service.rb"
require_relative "./task_state_manager.rb"

# 获取命令行参数
tmp_json_path = ARGV[0]
start_date = ARGV[1]
end_date = ARGV[2]

###
# app_measure_interval_extend
# 销量 iap
# 销售额 sales
#
# 展示次数 impressionsTotal
# 展示次数（独立设备）impressionsTotalUnique
# 产品页面查看次数 pageViewCount
# 产品页面查看次数（独立设备） pageViewUnique
# 下载总数 totalDownloads
# 首次下载 units
###

# 默认配置
$app_analytics_dataset_sources = ["Search"]
$app_analytics_dataset_devices = ["iPhone", "iPad"]
$app_analytics_dataset_regions = [
  "143441", "143444", "143465", "143462", "143466",
  "143470", "143443", "143450", "143442", "143454",
  "143468", "143453", "143503", "143469", "143480",
  "143471", "143476", "143475", "143473", "143479",
] # 常用的20个国家地区

# App分析数据集 上传
def get_app_analytics_dataset_config
  begin
    uri = URI("http://datareport.softinkit.com/dashboard/app-analytics-dataset/config")

    Net::HTTP.start(uri.host, uri.port) do |http|
      req = Net::HTTP::Get.new(uri, "Content-Type" => "application/json;charset=utf-8;")
      res = http.request(req)

      json = JSON.parse(res.body.force_encoding("UTF-8"))
      $app_analytics_dataset_sources = json&.[]("sources") || $app_analytics_dataset_sources
      $app_analytics_dataset_devices = json&.[]("devices") || $app_analytics_dataset_devices
      $app_analytics_dataset_regions = json&.[]("regions") || $app_analytics_dataset_regions
    end
  rescue => e
    puts "请求配置错误，将使用默认配置"
  end
end

def main(apple_account, apple_account_pwd, apple_account_name, start_date, end_date)
  # tunes登录
  tunes = Spaceship::Tunes.login(apple_account, apple_account_pwd)
  FastlaneCore::UI.message("登录成功")
  apps = Spaceship::Tunes::Application.all

  # 使用系统
  tmp_dir = File.join(Dir.tmpdir, "app_analytics_tasks")
  task_manager = TaskStateManager.new(tmp_dir)

  # 定义所有需要执行的任务
  upload_tasks = [
    # 新的数据获取
    [:upload_app_analytics_dataset_source, "数据集-来源"], # 数据集-来源
    [:upload_app_analytics_dataset_device, "数据集-设备"], # 数据集-设备
    [:upload_app_analytics_dataset_retention, "数据集-留存率"],

    [:upload_proceeds, "营收数据"],
    [:upload_app_analytics, "应用分析数据"],
    [:upload_retention, "留存率数据"],
    [:upload_benchmarks, "基准数据"],
  ]

  # 获取远程App分析数据集配置
  get_app_analytics_dataset_config

  FastlaneCore::UI.message("====== 开始，共#{apps.size}个应用")

  task_manager.reset_state

  # 使用最新的App List
  apps.each_with_index do |app, index|
    FastlaneCore::UI.message("------ #{index + 1}. #{app.name} 开始")

    unless task_manager.should_process_app?(app.bundle_id)
      FastlaneCore::UI.message("跳过应用：#{app.name}")
      next
    end

    connect_api_app = Spaceship::ConnectAPI::App.find(app.bundle_id)

    if connect_api_app
      # 记录错误的任务
      current_failed_tasks = []

      upload_service = UploadService.new(
        app,
        tunes,
        connect_api_app,
        apple_account,
        apple_account_name,
        start_date,
        end_date,
        task_manager,
        current_failed_tasks,
        $app_analytics_dataset_sources,
        $app_analytics_dataset_devices,
        $app_analytics_dataset_regions,
      )

      upload_tasks.each do |task, task_name|
        unless task_manager.should_process_task?(app.bundle_id, task)
          FastlaneCore::UI.message("跳过任务：#{task_name}")
          next
        end

        begin
          upload_service.send(task)
        rescue => error # StandardError
          puts "\n"
          FastlaneCore::UI.error("#{task_name}上报失败: #{error.message}")
        end
      end

      # 执行完当前应用的所有任务后，更新应用状态
      task_manager.mark_app_success(app.bundle_id)

      FastlaneCore::UI.message("------ #{index + 1}. #{app.name} 结束")
    else
      FastlaneCore::UI.error("无法通过Bundle_ID：#{app.bundle_id}，找到应用")
      update_app_state(app.bundle_id, app.name)
    end
  end

  if task_manager.has_failed_app
    FastlaneCore::UI.error("存在执行失败的应用，请重新上传。重新上传将跳过执行成功的应用。")
  end
end

if tmp_json_path && start_date && end_date
  json = File.read(tmp_json_path)
  obj = JSON.parse(json)

  apple_account_name = obj["apple_account_name"]
  apple_account = obj["apple_account"]
  password = obj["password"]
  if apple_account_name && apple_account && password
    main(apple_account, password, apple_account_name, start_date, end_date)
  else
    puts "找不到账号!"
  end
else
  puts "请检查参数！"
end
