arr = [1, 2, 3, 4, 5]

threads = []
results = []
mutex = Mutex.new

arr.each do |item|
  threads << Thread.new do
    result = { index: item, success: false, error: nil }

    sleep(rand(5))

    # mutex.synchronize do
    #   results << result
    # end
    results << result
  end

  # 控制并发数量
  if threads.size >= 3
    threads.each(&:join)
    threads.clear
  end
end

# 等待所有剩余线程完成
threads.each(&:join)

results.each do |result|
  next unless result

  puts result
end
