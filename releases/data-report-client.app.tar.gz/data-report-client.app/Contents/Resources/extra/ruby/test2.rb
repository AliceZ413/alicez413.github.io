require "pp"
require "json"
require "net/http"

app_analytics_data = []
data_map = {}
apple_id = "6450733441"

app_analytics_dataset_measure_types = [
  "impressionsTotalUnique", # 展示次数（独立设备）
  "totalDownloads", # 下载总数
  "conversionRate", # 转化率
]

app_analytics_dataset_devices = [
  "iPad",
  "iPhone",
]

begin
  begin
    app_analytics_dataset_measure_types.each do |measure_type|
      dimension_type = "device"
      app_analytics_dataset_devices.each do |device|
        if measure_type == "impressionsTotalUnique"
          data = [
            {
              "group" => {
                "key" => "123",
              },
              "data" => [
                {
                  "date" => "2025-03-17T00:00:00Z",
                  "impressionsTotalUnique" => 20,
                },
                {
                  "date" => "2025-03-16T00:00:00Z",
                  "impressionsTotalUnique" => 19,
                },
                {
                  "date" => "2025-03-15T00:00:00Z",
                  "impressionsTotalUnique" => 18,
                },
              ],
            },
            {
              "group" => {
                "key" => "456",
              },
              "data" => [
                {
                  "date" => "2025-03-17T00:00:00Z",
                  "impressionsTotalUnique" => 30,
                },
                {
                  "date" => "2025-03-16T00:00:00Z",
                  "impressionsTotalUnique" => 31,
                },
                {
                  "date" => "2025-03-15T00:00:00Z",
                  "impressionsTotalUnique" => 32,
                },
              ],
            },
          ]
        elsif measure_type == "totalDownloads"
          data = [
            {
              "group" => {
                "key" => "123",
              },
              "data" => [
                {
                  "date" => "2025-03-17T00:00:00Z",
                  "totalDownloads" => 20,
                },
                {
                  "date" => "2025-03-16T00:00:00Z",
                  "totalDownloads" => 19,
                },
                {
                  "date" => "2025-03-15T00:00:00Z",
                  "totalDownloads" => 18,
                },
              ],
            },
            {
              "group" => {
                "key" => "456",
              },
              "data" => [
                {
                  "date" => "2025-03-17T00:00:00Z",
                  "totalDownloads" => 30,
                },
                {
                  "date" => "2025-03-16T00:00:00Z",
                  "totalDownloads" => 31,
                },
                {
                  "date" => "2025-03-15T00:00:00Z",
                  "totalDownloads" => 32,
                },
              ],
            },
          ]
        elsif measure_type == "conversionRate"
          data = [
            {
              "group" => {
                "key" => "123",
              },
              "data" => [
                {
                  "date" => "2025-03-17T00:00:00Z",
                  "conversionRate" => 20,
                },
                {
                  "date" => "2025-03-16T00:00:00Z",
                  "conversionRate" => 19,
                },
                {
                  "date" => "2025-03-15T00:00:00Z",
                  "conversionRate" => 18,
                },
              ],
            },
            {
              "group" => {
                "key" => "456",
              },
              "data" => [
                {
                  "date" => "2025-03-17T00:00:00Z",
                  "conversionRate" => 30,
                },
                {
                  "date" => "2025-03-16T00:00:00Z",
                  "conversionRate" => 31,
                },
                {
                  "date" => "2025-03-15T00:00:00Z",
                  "conversionRate" => 32,
                },
              ],
            },
          ]
        end

        data.each do |item|
          region_code = item["group"]["key"]
          analytics_data = item["data"]

          analytics_data.each do |daily_data|
            date = daily_data["date"]
            key = "#{region_code}_#{device}_#{date}"

            data_map[key] ||= {
              "region_code" => region_code,
              "dimension_type" => dimension_type,
              "dimension" => device,
              "date" => date,
            }

            data_map[key][measure_type] = daily_data[measure_type]
          end
        end
      end
    end

    app_analytics_data = data_map.values

    # pp app_analytics_data

    begin
      uri = URI("http://localhost:5001/dashboard/app-analytics-dataset")
      Net::HTTP.start(uri.host, uri.port) do |http|
        req = Net::HTTP::Post.new(uri, "Content-Type" => "application/json")
        req.body = {
          "app_id": apple_id,
          "data": app_analytics_data,
        }.to_json
        res = http.request(req)

        unless res.is_a?(Net::HTTPSuccess)
          raise StandardError.new("上传响应错误：#{res.message}")
        end
      end
    rescue => e
      raise StandardError.new("上传响应错误：#{e.message}")
    end
  rescue => e
    raise StandardError.new("获取数据失败：#{e.message}")
  end
rescue StandardError => e
  raise e
end
