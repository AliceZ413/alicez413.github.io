require_relative "./upload_service_test.rb"

upload_service = UploadServiceTest.new(["upload_app_analytics", "upload_retention"])

upload_service.upload_app_analytics_dataset
