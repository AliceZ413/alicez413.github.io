require_relative "./task_state_manager.rb"
require_relative "./upload_service_test.rb"

tmp_dir = File.join(Dir.tmpdir, "app_analytics_tasks")
task_manager = TaskStateManager.new(tmp_dir)

app_analytics_dataset_sources = ["Search"]
app_analytics_dataset_devices = ["iPhone", "iPad"]
app_analytics_dataset_regions = ["143441", "143465", "143462", "143466"]

# App分析数据集 上传
def get_app_analytics_dataset_config
  begin
    fetch_app_analytics_dataset_config
  rescue => e
    puts "请求配置错误，将使用默认配置"
  end
end

# 获取App分析数据集配置
def fetch_app_analytics_dataset_config
  uri = URI("http://darareport.softinkit.com/dashboard/app-analytics-dataset/config") # TODO 替换生产地址

  Net::HTTP.start(uri.host, uri.port) do |http|
    req = Net::HTTP::Get.new(uri, "Content-Type" => "application/json;charset=utf-8;")
    res = http.request(req)

    json = JSON.parse(res.body.force_encoding("UTF-8"))
    app_analytics_dataset_sources = json&.[]("sources")
    app_analytics_dataset_devices = json&.[]("devices")
    app_analytics_dataset_regions = json&.[]("regions")
  end
end

apps = [
  {
    "apple_id" => 111,
    "bundle_id" => "com.111",
    "name" => "应用111",
  },
  {
    "apple_id" => 222,
    "bundle_id" => "com.222",
    "name" => "应用222",
  },
]

# 定义所有需要执行的任务
upload_tasks = [
  # 新的数据获取
  [:upload_app_analytics_dataset_source, "数据集-来源"],
  # [:upload_app_analytics_dataset_device, "数据集-设备"],
  # [:upload_app_analytics_dataset_impression_unique_device_source, "数据集-展示次数(独立设备)-来源"],
  # [:upload_app_analytics_dataset_impression_unique_device_device, "数据集-展示次数(独立设备)-设备"],
  # [:upload_app_analytics_dataset_total_downloads_source, "数据集-下载总数-来源"],
  # [:upload_app_analytics_dataset_total_downloads_device, "数据集-下载总数-设备"],
  # [:upload_app_analytics_dataset_conversion_rate_source, "数据集-转化率-来源"],
  # [:upload_app_analytics_dataset_conversion_rate_device, "数据集-转化率-设备"],
  # [:upload_app_analytics_dataset_retention, "数据集-留存率"],

  # 过去的数据获取
  [:upload_proceeds, "营收数据"],
  [:upload_app_analytics, "应用分析数据"],
  [:upload_retention, "留存率数据"],
  [:upload_benchmarks, "基准数据"],
]

# 需要模拟错误的任务
mock_fail_tasks = ["upload_app_analytics_dataset_source", "美国", "中国大陆"]

# 获取远程App分析数据集配置
get_app_analytics_dataset_config

FastlaneCore::UI.message("====== 开始，共#{apps.size}个应用")

apps.each_with_index do |app, index|
  FastlaneCore::UI.message("------ #{index + 1}. #{app["name"]} 开始")

  unless task_manager.should_process_app?(app["bundle_id"])
    FastlaneCore::UI.message("跳过应用：#{app["name"]}")
    next
  end

  current_failed_tasks = []

  upload_service = UploadServiceTest.new(
    app,
    task_manager,
    current_failed_tasks,
    mock_fail_tasks,
    app_analytics_dataset_sources,
    app_analytics_dataset_devices,
    app_analytics_dataset_regions,
  ) # ["upload_app_analytics_dataset_impression_unique_device", "upload_benchmarks"]

  # 模拟执行任务
  upload_tasks.each do |task, task_name|
    # 检查是否需要执行这个任务
    unless task_manager.should_process_task?(app["bundle_id"], task)
      FastlaneCore::UI.message("跳过任务: #{task_name}")
      next
    end

    begin
      upload_service.send(task)
    rescue => e
      puts "\n"
      FastlaneCore::UI.error("#{task_name}上报失败: #{e.message}")
    end
  end

  # 执行完所有任务后，更新应用成功状态
  task_manager.mark_app_success(app["bundle_id"])

  FastlaneCore::UI.message("------ #{index + 1}. #{app["name"]} 结束")
end

if task_manager.has_failed_app
  FastlaneCore::UI.error("存在执行失败的应用，请重新上传。重新上传将跳过执行成功的应用。")
end
