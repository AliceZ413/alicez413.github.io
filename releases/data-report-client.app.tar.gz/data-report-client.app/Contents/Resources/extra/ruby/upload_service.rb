require "fastlane_core"
require_relative "./shared-values.rb"

class UploadService
  def initialize(app, tunes, connect_api_app, apple_account, apple_account_name, start_date, end_date, task_manager, current_failed_tasks, app_analytics_dataset_sources, app_analytics_dataset_devices, app_analytics_dataset_regions)
    @app = app
    @tunes = tunes
    @connect_api_app = connect_api_app
    @apple_account = apple_account
    @apple_account_name = apple_account_name
    @start_date = start_date
    @end_date = end_date
    @measure_types_list = [
      "impressionsTotal",
      "impressionsTotalUnique",
      "pageViewCount",
      "pageViewUnique",
      "totalDownloads",
      "units",
      "activeDevices",
    ]
    @random_regions = SharedValues::get_random_regions(4)
    # App分析数据集
    @app_analytics_dataset_measure_types = [
      "impressionsTotalUnique", # 展示次数（独立设备）
      "totalDownloads", # 下载总数
      "conversionRate", # 转化率
    ]

    @task_manager = task_manager
    @current_failed_tasks = current_failed_tasks

    @app_analytics_dataset_sources = app_analytics_dataset_sources
    @app_analytics_dataset_devices = app_analytics_dataset_devices
    @app_analytics_dataset_regions = app_analytics_dataset_regions
  end

  # 数据集-来源
  def upload_app_analytics_dataset_source
    task = "upload_app_analytics_dataset_source"
    task_name = "数据集-来源"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    apple_id = @app.apple_id
    analytics = @app.analytics
    app_analytics_data = [] # [{ app_id, region_code, dimension_type, dimension, data: [{ date, impression, total, conversion }] }]
    data_map = {} # 临时存储和合并数据的哈希表

    begin
      if @connect_api_app.get_live_app_store_version.nil?
        # 如果没有live_version则跳过获取和上传，直接判断完成
      else
        begin
          @app_analytics_dataset_measure_types.each do |measure_type|
            dimension_type = "source"
            @app_analytics_dataset_sources.each do |source|
              data = get_from_app_analytics(
                analytics,
                @start_date,
                @end_date,
                measure_type,
                [{ "dimensionKey": dimension_type, "optionKeys": [source] }],
                "storefront"
              )

              data.each do |item|
                region_code = item["group"]["key"]
                analytics_data = item["data"]

                analytics_data.each do |daily_data|
                  date = daily_data["date"]
                  key = "#{region_code}_#{source}_#{date}"

                  data_map[key] ||= {
                    "region_code" => region_code,
                    "dimension_type" => dimension_type,
                    "dimension" => source,
                    "date" => date,
                  }

                  data_map[key][measure_type] = daily_data[measure_type]
                end
              end
            end
          end

          app_analytics_data = data_map.values
        rescue => e
          raise StandardError.new("获取数据失败：#{e.message}")
        end

        begin
          uri = URI("http://datareport.softinkit.com/dashboard/app-analytics-dataset")
          Net::HTTP.start(uri.host, uri.port) do |http|
            req = Net::HTTP::Post.new(uri, "Content-Type" => "application/json")
            req.body = {
              "app_id": apple_id,
              "data": app_analytics_data,
            }.to_json
            res = http.request(req)

            unless res.is_a?(Net::HTTPSuccess)
              raise StandardError.new("上传响应错误：#{res.message}")
            end
          end
        rescue => e
          raise StandardError.new("上传响应错误：#{e.message}")
        end
      end

      @task_manager.update_task_state(
        @app.bundle_id,
        @app.name,
        task,
        task_name,
        true
      )
    rescue StandardError => e
      # 更新失败状态
      @task_manager.update_task_state(
        @app.bundle_id,
        @app.name,
        task,
        task_name,
        false,
      )
      raise e
    ensure
      FastlaneCore::Helper.hide_loading_indicator
    end
  end

  # 数据集-设备
  def upload_app_analytics_dataset_device
    task = "upload_app_analytics_dataset_device"
    task_name = "数据集-设备"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    apple_id = @app.apple_id
    analytics = @app.analytics
    app_analytics_data = [] # [{ app_id, region_code, dimension_type, dimension, data: [{ date, impression, total, conversion }] }]
    data_map = {} # 临时存储和合并数据的哈希表

    begin
      if @connect_api_app.get_live_app_store_version?
        # 如果没有live_version则跳过获取和上传，直接判断完成
      else
        begin
          @app_analytics_dataset_measure_types.each do |measure_type|
            dimension_type = "device"
            @app_analytics_dataset_devices.each do |device|
              data = get_from_app_analytics(
                analytics,
                @start_date,
                @end_date,
                measure_type,
                [{ "dimensionKey": dimension_type, "optionKeys": [device] }],
                "storefront"
              )

              data.each do |item|
                region_code = item["group"]["key"]
                analytics_data = item["data"]

                analytics_data.each do |daily_data|
                  date = daily_data["date"]
                  key = "#{region_code}_#{device}_#{date}"

                  data_map[key] ||= {
                    "region_code" => region_code,
                    "dimension_type" => dimension_type,
                    "dimension" => device,
                    "date" => date,
                  }

                  data_map[key][measure_type] = daily_data[measure_type]
                end
              end
            end
          end

          app_analytics_data = data_map.values
        rescue => e
          raise StandardError.new("获取数据失败：#{e.message}")
        end

        begin
          uri = URI("http://datareport.softinkit.com/dashboard/app-analytics-dataset")
          Net::HTTP.start(uri.host, uri.port) do |http|
            req = Net::HTTP::Post.new(uri, "Content-Type" => "application/json")
            req.body = {
              "app_id": apple_id,
              "data": app_analytics_data,
            }.to_json
            res = http.request(req)

            unless res.is_a?(Net::HTTPSuccess)
              raise StandardError.new("上传响应错误：#{res.message}")
            end
          end
        rescue => e
          raise StandardError.new("上传响应错误：#{e.message}")
        end
      end

      @task_manager.update_task_state(
        @app.bundle_id,
        @app.name,
        task,
        task_name,
        true
      )
    rescue StandardError => e
      # 更新失败状态
      @task_manager.update_task_state(
        @app.bundle_id,
        @app.name,
        task,
        task_name,
        false,
      )
      raise e
    ensure
      FastlaneCore::Helper.hide_loading_indicator
    end
  end

  # 数据集-留存率
  def upload_app_analytics_dataset_retention
    task = "upload_app_analytics_dataset_retention"
    task_name = "数据集-留存率"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    apple_id = @app.apple_id
    analytics = @app.analytics

    if @connect_api_app.get_live_app_store_version.nil?
      # 如果没有live_version则跳过获取和上传，直接判断完成
    else
      if @task_manager.should_process_task?(@app.bundle_id, task)
        @app_analytics_dataset_regions.each do |region|
          unless @task_manager.should_process_subtask?(@app.bundle_id, task, "region", region)
            FastlaneCore::UI.message("跳过国家地区：#{region}")
            next
          end

          begin
            FastlaneCore::UI.message("处理国家地区 #{region}")

            dimension_filters = [{
              "dimensionKey": "storefront", # TODO 参数类型
              "optionKeys": [region],
            }]
            data = begin
                get_retention(analytics, @start_date, @end_date, dimension_filters)
              rescue => e
                raise StandardError.new("获取数据失败：#{e.message}")
              end

            uri = URI("http://datareport.softinkit.com/dashboard/app-analytics-dataset/retention")
            begin
              Net::HTTP.start(uri.host, uri.port) do |http|
                req = Net::HTTP::Post.new(uri, "Content-Type" => "application/json")
                req.body = {
                  "app_id": apple_id,
                  "region_code": region,
                  "results": data,
                }.to_json
                res = http.request(req)

                unless res.is_a?(Net::HTTPSuccess)
                  raise StandardError.new("上传响应错误: #{res.code} - #{res.message}")
                end
              end
              FastlaneCore::UI.success("国家地区 #{region} 处理成功")
            rescue => e
              raise StandardError.new("上传数据失败: #{e.message}")
            end

            # 更新子任务状态
            @task_manager.update_task_state(
              @app.bundle_id,
              @app.name,
              task,
              task_name,
              false,
              {
                key: "region",
                value: region,
                success: true,
              }
            )
          rescue StandardError => e
            FastlaneCore::UI.error("国家地区 #{region} 处理失败: #{e.message}")
            @task_manager.update_task_state(
              @app.bundle_id,
              @app.name,
              task,
              task_name,
              false,
              {
                key: "region",
                value: region,
                success: false,
              }
            )
          end
        end

        @task_manager.mark_app_success(@app.bundle_id)
      end
    end

    FastlaneCore::Helper.hide_loading_indicator
  end

  # 营收 上传方法
  def upload_proceeds
    task = "upload_proceeds"
    task_name = "营收数据"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    apple_id = @app.apple_id
    data = []

    begin
      if @connect_api_app.get_live_app_store_version.nil?
        # 非live_version时，为空值
        data = []
      else
        analytics = @app.analytics

        begin
          response = analytics.app_measure_interval(@start_date, @end_date, "proceeds")
          results = response["results"]
          iaps = @tunes.iaps(app_id: apple_id)
          if iaps.length > 0
            if results
              result = results[0]
              data = result["data"]
            else
              # 拿不到analytics数据时，为空值
              data = []
            end
          else
            # 没有内购项时，为空值
            data = []
          end
        rescue => e
          raise StandardError.new("获取数据失败：#{e.message}")
        end

        begin
          # 无论如何先上传
          uri = URI("http://datareport.softinkit.com/dashboard/proceeds/log/v2")
          Net::HTTP.start(uri.host, uri.port) do |http|
            req = Net::HTTP::Post.new(uri, "Content-Type" => "application/json")
            req.body = {
              "channel_type": "App Store",
              "apple_account": @apple_account,
              "apple_account_name": @apple_account_name,
              "app_id": apple_id,
              "data": data,
            }.to_json
            res = http.request(req)

            unless res.is_a?(Net::HTTPSuccess)
              raise StandardError.new("上传响应错误：#{res.message}")
            end
          end
        rescue => e
          raise StandardError.new("上传响应错误：#{e.message}")
        end
      end

      # 任务成功完成
      @task_manager.update_task_state(
        @app.bundle_id,
        @app.name,
        task,
        task_name,
        true
      )
    rescue StandardError => e
      # 更新失败状态
      @task_manager.update_task_state(
        @app.bundle_id,
        @app.name,
        task,
        task_name,
        false
      )
      raise e
    ensure
      FastlaneCore::Helper.hide_loading_indicator
    end
  end

  # App分析数据 上传方法
  def upload_app_analytics
    task = "upload_app_analytics"
    task_name = "应用分析数据"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    begin
      apple_id = @app.apple_id
      analytics = @app.analytics
      app_analytics_data = []

      if @connect_api_app.get_live_app_store_version.nil?
        # 如果没有live_version则跳过获取和上传，直接判断完成
      else
        begin
          for measure_types in @measure_types_list
            data = get_from_app_analytics(analytics, @start_date, @end_date, measure_types, [], "storefront")
            for itm in data
              region_code = itm["group"]["key"]
              region_name = itm["group"]["title"]
              analytics_data = itm["data"]

              exist = app_analytics_data.find { |i| i["region_code"] == region_code }

              if exist == nil
                obj = {
                  "region_code" => region_code,
                  "region_name" => region_name,
                  "analytics_data" => analytics_data,
                }
                app_analytics_data.push obj
              else
                # 用于合并的哈希表
                merged_data = merge_array(analytics_data, exist["analytics_data"])
                exist["analytics_data"] = merged_data
              end
            end
          end
        rescue => e
          raise StandardError.new("获取数据失败：#{e.message}")
        end

        begin
          uri = URI("http://datareport.softinkit.com/dashboard/app-analytics/log")
          Net::HTTP.start(uri.host, uri.port) do |http|
            req = Net::HTTP::Post.new(uri, "Content-Type" => "application/json")
            req.body = {
              "app_id": apple_id,
              "data": app_analytics_data,
            }.to_json
            res = http.request(req)

            unless res.is_a?(Net::HTTPSuccess)
              raise StandardError.new("上传响应错误：#{res.message}")
            end
          end
        rescue => e
          raise StandardError.new("上传响应错误：#{e.message}")
        end
      end

      @task_manager.update_task_state(
        @app.bundle_id,
        @app.name,
        task,
        task_name,
        true
      )
    rescue StandardError => e
      # 更新失败状态
      @task_manager.update_task_state(
        @app.bundle_id,
        @app.name,
        task,
        task_name,
        false,
      )
      raise e
    ensure
      FastlaneCore::Helper.hide_loading_indicator
    end
  end

  # 留存率 上传方法
  def upload_retention
    task = "upload_retention"
    task_name = "留存率数据"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    begin
      apple_id = @app.apple_id
      analytics = @app.analytics

      if @connect_api_app.get_live_app_store_version.nil?
        # 如果没有live_version则跳过获取和上传，直接判断完成
      else
        begin
          results = get_retention(analytics, @start_date, @end_date)
          data = []
          if !results.empty?
            results.each do |item|
              temp_data = item["data"]
              data.push(temp_data[1]) if temp_data # 空值检查
            end
          end
        rescue => e
          raise StandardError.new("获取数据失败：#{e.message}")
        end

        begin
          uri = URI("http://datareport.softinkit.com/dashboard/app-analytics/retention/log")
          Net::HTTP.start(uri.host, uri.port) do |http|
            req = Net::HTTP::Post.new(uri, "Content-Type" => "application/json")
            req.body = {
              "app_id": apple_id,
              "data": data,
            }.to_json
            res = http.request(req)

            unless res.is_a?(Net::HTTPSuccess)
              raise StandardError.new("上传响应错误：#{res.message}")
            end
          end
        rescue => e
          raise StandardError.new("上传响应错误：#{e.message}")
        end
      end

      @task_manager.update_task_state(
        @app.bundle_id,
        @app.name,
        task,
        task_name,
        true
      )
    rescue StandardError => e
      # 更新失败状态
      @task_manager.update_task_state(
        @app.bundle_id,
        @app.name,
        task,
        task_name,
        false,
      )
      raise e
    ensure
      FastlaneCore::Helper.hide_loading_indicator
    end
  end

  # 对等组数据 上传方法
  def upload_benchmarks
    task = "upload_retention"
    task_name = "基准数据"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    apple_id = @app.apple_id
    analytics = @app.analytics
    # 日期处理
    # 开始日期和结束日期为end_date的三周前的周一
    date = get_three_weeks_ago(@end_date)

    # 获取应用的分类ID
    genre_id = get_app_primary_genre_id(apple_id, @end_date)

    begin
      if @connect_api_app.get_live_app_store_version.nil?
        # 如果没有live_version则跳过获取和上传，直接判断完成
        @task_manager.update_task_state(
          @app.bundle_id,
          @app.name,
          task,
          task_name,
          true,
        )
      else
        if genre_id.nil?
          raise StandardError.new("无法从外部获取应用(#{app_id})的分类ID")
        end

        begin
          dimension_values = get_dimension_values(analytics, @end_date)
          peerGroupIds = dimension_values.select { |e|
            e["size"] == "ALL" && e["category"] == "GENRE_#{genre_id}"
          }.map { |e|
            e["id"]
          }

          res_1 = analytics.app_measure_interval_v2(
            date,
            date,
            ["benchCrashRate", "benchRetentionD1", "benchRetentionD7", "benchRetentionD28", "benchConversionRate", "benchArppu"],
            "week",
            [{ dimensionKey: "peerGroupId", optionKeys: peerGroupIds }]
          )
          peer_group_benchmark = res_1&.[]("results")&.[](0)&.[]("data")&.[](0)

          # 应用基准数据
          res_2 = analytics.app_measure_interval_v2(
            date,
            date,
            ["crashRate", "retentionD1", "retentionD7", "retentionD28", "conversionRate", "arppu"],
            "week",
            []
          )
          app_benchmark = res_2&.[]("results")&.[](0)&.[]("data")&.[](0)
        rescue => e
          raise StandardError.new("获取数据失败：#{e.message}")
        end

        if !peer_group_benchmark.nil? && !app_benchmark.nil?
          request_body = {
            app_id: apple_id,
            apple_account: @apple_account,
            date: date,
            benchmarks: [
              {
                genre_id: genre_id,
                app: app_benchmark,
                peer_group_benchmark: peer_group_benchmark,
              },
            ],
          }

          begin
            uri = URI("http://datareport.softinkit.com/dashboard/peer-group-benchmark/report")
            Net::HTTP.start(uri.host, uri.port) do |http|
              req = Net::HTTP::Post.new(uri, "Content-Type" => "application/json")
              req.body = request_body.to_json
              res = http.request(req)

              unless res.is_a?(Net::HTTPSuccess)
                raise StandardError.new("上传响应错误：#{res.message}")
              end
            end
          rescue => e
            raise StandardError.new("上传响应错误：#{e.message}")
          end

          @task_manager.update_task_state(
            @app.bundle_id,
            @app.name,
            task,
            task_name,
            true
          )
        else
          # 没有触发上传，任务也算失败
          raise StandardError.new("缺少必要的数据：#{e.message}")
        end
      end
    rescue StandardError => e
      # 更新失败状态
      @task_manager.update_task_state(
        @app.bundle_id,
        @app.name,
        task,
        task_name,
        false,
      )
      raise e
    ensure
      FastlaneCore::Helper.hide_loading_indicator
    end
  end

  private

  def get_from_app_analytics(analytics, start_date, end_date, measure, dimension_filters, view_by)
    response = analytics.app_measure_interval_extend(start_date, end_date, measure, dimension_filters, view_by)
    results = response["results"]
    if results
      result = results
    else
      result = []
    end
  end

  def get_retention(analytics, start_date, end_date, dimension_filters = [])
    response = analytics.app_retention_interval(start_date, end_date, dimension_filters)

    response["results"] || []
  end

  # 获取dimension_values
  def get_dimension_values(analytics, date)
    response = analytics.dimension_values(
      "2015-04-01T00:00:00Z", # 固定
      date,
      ["benchCrashRate", "benchRetentionD1", "benchRetentionD7", "benchRetentionD28", "benchConversionRate", "benchArppu"],
      "week",
      [],
      []
    )
    results = response["results"]
    if results
      result = results[0]["values"]
    else
      result = []
    end
    result
  end

  # 通用辅助方法
  def perform_upload(uri, body)
    Net::HTTP.start(uri.host, uri.port) do |http|
      req = Net::HTTP::Post.new(uri, "Content-Type" => "application/json")
      req.body = body.to_json
      res = http.request(req)

      unless res.is_a?(Net::HTTPSuccess)
        raise "Upload failed with status: #{res.code}"
      end
    end
  end

  def merge_analytics_data(app_analytics_data, new_data)
    new_data.each do |itm|
      region_code = itm["group"]["key"]
      region_name = itm["group"]["title"]
      analytics_data = itm["data"]

      exist = app_analytics_data.find { |i| i["region_code"] == region_code }

      if exist.nil?
        app_analytics_data.push({
          "region_code" => region_code,
          "region_name" => region_name,
          "analytics_data" => analytics_data,
        })
      else
        exist["analytics_data"] = merge_array(analytics_data, exist["analytics_data"])
      end
    end
  end

  def merge_array(array1, array2)
    # 用于存储合并后的数据
    c_array1 = array1.clone
    c_array2 = array2.clone

    i = 0
    array_length = c_array1.length
    begin
      c_array1[i].merge! c_array2[i]
      i += 1
    rescue => exception
      raise exception
    end while i <= array_length - 1

    c_array1
  end

  # 获取三周前的周一
  def get_three_weeks_ago(date)
    original_date = Date.strptime(date, "%FT00:00:00Z")
    three_weeks_ago = original_date - 21
    monday_of_three_weeks_ago = three_weeks_ago - three_weeks_ago.wday + 1
    monday_of_three_weeks_ago.strftime("%FT00:00:00Z")
  end

  # 获取app primary_genre_id
  def get_app_primary_genre_id(app_id, date)
    genre_id = fetch_app_genre(app_id, "US")

    if genre_id.nil?
      @random_regions.each { |region|
        genre_id = fetch_app_genre(app_id, region)
        if !genre_id.nil?
          break
        end
      }
    end

    if genre_id.nil?
      FastlaneCore::UI.error("无法从外部获取应用#{app_id}的分类")
    else
      genre_id
    end
  end

  # 请求genre id
  def fetch_app_version(app_id, region)
    uri = URI("http://proxies.flowever.net/1.1/qimai/version")
    params = { :country => region, :appid => app_id }
    uri.query = URI.encode_www_form(params)
    result = []

    Net::HTTP.start(uri.host, uri.port) do |http|
      req = Net::HTTP::Get.new(uri, "Content-Type" => "application/json;charset=utf-8;")
      res = http.request(req)

      json = JSON.parse(res.body.force_encoding("UTF-8"))
      if json&.[]("result")&.[]("version").nil?
        result
      else
        result = json["result"]["version"]
      end
    end
    result.map { |e|
      {
        release_time: parse_chinese_date(e["release_time"]),
        genre_id: e["genre_id"],
        genre_name: e["genre_name"],
      }
    }
  end

  def fetch_app_genre(app_id, region)
    uri = URI("http://proxies.flowever.net/1.1/appstore/lookup")
    params = { :country => region, :id => app_id }
    uri.query = URI.encode_www_form(params)
    primaryGenreId = 0

    Net::HTTP.start(uri.host, uri.port) do |http|
      req = Net::HTTP::Get.new(uri, "Content-Type" => "application/json;charset=utf-8;")
      res = http.request(req)

      json = JSON.parse(res.body.force_encoding("UTF-8"))
      primaryGenreId = json&.[]("results")&.first&.[]("primaryGenreId")
    end

    if primaryGenreId.nil?
      return nil
    else
      return primaryGenreId
    end
  end

  def parse_chinese_date(chinese_date_str)
    # 使用正则表达式提取日期和时间部分
    match = chinese_date_str.match(/(\d{4})年(\d{2})月(\d{2})日/)
    if match
      year = match[1].to_i
      month = match[2].to_i
      day = match[3].to_i

      # 创建时间对象
      Date.new(year, month, day).strftime("%FT00:00:00Z")
    else
      raise ArgumentError, "日期格式不正确"
    end
  end
end
