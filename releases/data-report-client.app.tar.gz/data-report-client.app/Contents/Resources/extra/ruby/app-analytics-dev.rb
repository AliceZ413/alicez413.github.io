# ruby resources/script/fetch-analytics-prod.rb [config_path]
require 'net/http'
require 'uri'
require 'json'
require 'pp'
require 'spaceship'
require 'faraday'
require 'date'
require_relative './shared-values.rb'

# 获取命令行参数
# config_path = ARGV[0]
# puts "#{config_path}"

tmp_json_path = ARGV[0]
start_date = ARGV[1]
end_date = ARGV[2]

def fetch_app_version(app_id, region)
    conn = Faraday.new(url: "http://proxies.flowever.net") do |builder|
        builder.response :json
    end
    response = conn.get('/1.1/qimai/version') do |req|
        req.params['country'] = region
        req.params['appid'] = app_id
    end
    result = []
    if response.body&.[]('result')&.[]('version').nil?
        result
    else
        result = response.body['result']['version']
    end
    result.map { |e|
        {
            release_time: parse_chinese_date(e['release_time']),
            genre_id: e['genre_id'],
            genre_name: e['genre_name']
        }
    }
end

def parse_chinese_date(chinese_date_str)
    # 使用正则表达式提取日期和时间部分
    match = chinese_date_str.match(/(\d{4})年(\d{2})月(\d{2})日/)
    if match
      year = match[1].to_i
      month = match[2].to_i
      day = match[3].to_i

      # 创建时间对象
      Date.new(year, month, day).strftime('%FT00:00:00Z')
    else
      raise ArgumentError, "日期格式不正确"
    end
end

random_regions = SharedValues::get_random_regions(4)
pp random_regions

genre_id = nil

random_regions.each { |region|
    genre_id = fetch_app_version(6499185185, region)
    pp genre_id
    if !genre_id.nil?
        break
    end
}

pp "finally: #{genre_id}"

# if tmp_json_path && start_date && end_date
#     json = File.read(tmp_json_path)
#     obj = JSON.parse(json)

#     apple_account_name = obj['apple_account_name']
#     apple_account = obj['apple_account']
#     password = obj['password']
#     if apple_account_name && apple_account && password
#         pp apple_account_name, apple_account, password
#     else
#         puts "找不到账号"
#     end
# else
#     puts "请检查参数！[ruby:app-analytics:params-error]"
# end
