require "fastlane_core"

class UploadServiceTest
  def initialize(app, task_manager, current_failed_tasks, fail_tasks, app_analytics_dataset_sources, app_analytics_dataset_devices, app_analytics_dataset_regions)
    @app = app
    @task_manager = task_manager
    @current_failed_tasks = current_failed_tasks
    @fail_tasks = fail_tasks.map(&:to_s)
    @app_analytics_dataset_sources = app_analytics_dataset_sources
    @app_analytics_dataset_devices = app_analytics_dataset_devices
    @app_analytics_dataset_regions = app_analytics_dataset_regions
  end

  # 数据集-展示次数(独立设备)-来源
  def upload_app_analytics_dataset_impression_unique_device_source
    task = "upload_app_analytics_dataset_impression_unique_device_source"
    task_name = "数据集-展示次数(独立设备)-来源"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    if @task_manager.should_process_task?(@app["bundle_id"], task)
      # fail_if_configured(task, "数据集分析")
      @app_analytics_dataset_sources.each do |source|
        unless @task_manager.should_process_subtask?(@app["bundle_id"], task, "source", source)
          FastlaneCore::UI.message("跳过数据源：#{source}")
          next
        end

        begin
          FastlaneCore::UI.message("处理数据源：#{source}")
          fail_if_configured(source, "数据源#{source}")
          # 更新子任务状态
          @task_manager.update_task_state(
            @app["bundle_id"],
            @app["name"],
            task,
            "数据集分析",
            false,
            {
              key: "source",
              value: source,
              success: true,
            }
          )
        rescue StandardError => e
          FastlaneCore::UI.error("数据源 #{source} 处理失败: #{e.message}")
          # 更新子任务状态
          @task_manager.update_task_state(
            @app["bundle_id"],
            @app["name"],
            task,
            "数据集分析",
            false,
            {
              key: "source",
              value: source,
              success: false,
            }
          )
        end
      end

      # 子任务结束后判断父任务是否已完成
      @task_manager.mark_task_success(@app["bundle_id"], task)
    end

    FastlaneCore::Helper.hide_loading_indicator
  end

  # 数据集-展示次数(独立设备)-设备
  def upload_app_analytics_dataset_impression_unique_device_device
    task = "upload_app_analytics_dataset_impression_unique_device_device"
    task_name = "数据集-展示次数(独立设备)-设备"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    if @task_manager.should_process_task?(@app["bundle_id"], task)
      # fail_if_configured(task, "数据集分析")
      @app_analytics_dataset_devices.each do |device|
        unless @task_manager.should_process_subtask?(@app["bundle_id"], task, "device", device)
          FastlaneCore::UI.message("跳过设备：#{device}")
          next
        end

        begin
          FastlaneCore::UI.message("处理设备：#{device}")
          fail_if_configured(device, "设备#{device}")
          # 更新子任务状态
          @task_manager.update_task_state(
            @app["bundle_id"],
            @app["name"],
            task,
            "数据集分析",
            false,
            {
              key: "device",
              value: device,
              success: true,
            }
          )
        rescue StandardError => e
          FastlaneCore::UI.error("数据源 #{device} 处理失败: #{e.message}")
          # 更新子任务状态
          @task_manager.update_task_state(
            @app["bundle_id"],
            @app["name"],
            task,
            "数据集分析",
            false,
            {
              key: "device",
              value: device,
              success: false,
            }
          )
        end
      end

      # 子任务结束后判断父任务是否已完成
      @task_manager.mark_task_success(@app["bundle_id"], task)
    end

    FastlaneCore::Helper.hide_loading_indicator
  end

  # 数据集-下载总数-来源
  def upload_app_analytics_dataset_total_downloads_source
    task = "upload_app_analytics_dataset_total_downloads_source"
    task_name = "数据集-下载总数-来源"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    if @task_manager.should_process_task?(@app["bundle_id"], task)
      # fail_if_configured(task, "数据集分析")
      @app_analytics_dataset_sources.each do |source|
        unless @task_manager.should_process_subtask?(@app["bundle_id"], task, "source", source)
          FastlaneCore::UI.message("跳过数据源：#{source}")
          next
        end

        begin
          FastlaneCore::UI.message("处理数据源：#{source}")
          fail_if_configured(source, "数据源#{source}")
          # 更新子任务状态
          @task_manager.update_task_state(
            @app["bundle_id"],
            @app["name"],
            task,
            task_name,
            false,
            {
              key: "source",
              value: source,
              success: true,
            }
          )
        rescue StandardError => e
          FastlaneCore::UI.error("数据源 #{source} 处理失败: #{e.message}")
          # 更新子任务状态
          @task_manager.update_task_state(
            @app["bundle_id"],
            @app["name"],
            task,
            task_name,
            false,
            {
              key: "source",
              value: source,
              success: false,
            }
          )
        end
      end

      # 子任务结束后判断父任务是否已完成
      @task_manager.mark_task_success(@app["bundle_id"], task)
    end

    FastlaneCore::Helper.hide_loading_indicator
  end

  # 数据集-下载总数-设备
  def upload_app_analytics_dataset_total_downloads_device
    task = "upload_app_analytics_dataset_total_downloads_device"
    task_name = "数据集-下载总数-设备"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    if @task_manager.should_process_task?(@app["bundle_id"], task)
      # fail_if_configured(task, "数据集分析")
      @app_analytics_dataset_devices.each do |device|
        unless @task_manager.should_process_subtask?(@app["bundle_id"], task, "device", device)
          FastlaneCore::UI.message("跳过设备：#{device}")
          next
        end

        begin
          FastlaneCore::UI.message("处理设备：#{device}")
          fail_if_configured(device, "设备#{device}")
          # 更新子任务状态
          @task_manager.update_task_state(
            @app["bundle_id"],
            @app["name"],
            task,
            task_name,
            false,
            {
              key: "device",
              value: device,
              success: true,
            }
          )
        rescue StandardError => e
          FastlaneCore::UI.error("数据源 #{device} 处理失败: #{e.message}")
          # 更新子任务状态
          @task_manager.update_task_state(
            @app["bundle_id"],
            @app["name"],
            task,
            task_name,
            false,
            {
              key: "device",
              value: device,
              success: false,
            }
          )
        end
      end

      # 子任务结束后判断父任务是否已完成
      @task_manager.mark_task_success(@app["bundle_id"], task)
    end

    FastlaneCore::Helper.hide_loading_indicator
  end

  # 数据集-转化率-来源
  def upload_app_analytics_dataset_conversion_rate_source
    task = "upload_app_analytics_dataset_conversion_rate_source"
    task_name = "数据集-转化率-来源"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    if @task_manager.should_process_task?(@app["bundle_id"], task)
      # fail_if_configured(task, "数据集分析")
      @app_analytics_dataset_sources.each do |source|
        unless @task_manager.should_process_subtask?(@app["bundle_id"], task, "source", source)
          FastlaneCore::UI.message("跳过数据源：#{source}")
          next
        end

        begin
          FastlaneCore::UI.message("处理数据源：#{source}")
          fail_if_configured(source, "数据源#{source}")
          # 更新子任务状态
          @task_manager.update_task_state(
            @app["bundle_id"],
            @app["name"],
            task,
            task_name,
            false,
            {
              key: "source",
              value: source,
              success: true,
            }
          )
        rescue StandardError => e
          FastlaneCore::UI.error("数据源 #{source} 处理失败: #{e.message}")
          # 更新子任务状态
          @task_manager.update_task_state(
            @app["bundle_id"],
            @app["name"],
            task,
            task_name,
            false,
            {
              key: "source",
              value: source,
              success: false,
            }
          )
        end
      end

      # 子任务结束后判断父任务是否已完成
      @task_manager.mark_task_success(@app["bundle_id"], task)
    end

    FastlaneCore::Helper.hide_loading_indicator
  end

  # 数据集-转化率-设备
  def upload_app_analytics_dataset_conversion_rate_device
    task = "upload_app_analytics_dataset_conversion_rate_device"
    task_name = "数据集-转化率-设备"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    if @task_manager.should_process_task?(@app["bundle_id"], task)
      # fail_if_configured(task, "数据集分析")
      @app_analytics_dataset_devices.each do |device|
        unless @task_manager.should_process_subtask?(@app["bundle_id"], task, "device", device)
          FastlaneCore::UI.message("跳过设备：#{device}")
          next
        end

        begin
          FastlaneCore::UI.message("处理设备：#{device}")
          fail_if_configured(device, "设备#{device}")
          # 更新子任务状态
          @task_manager.update_task_state(
            @app["bundle_id"],
            @app["name"],
            task,
            task_name,
            false,
            {
              key: "device",
              value: device,
              success: true,
            }
          )
        rescue StandardError => e
          FastlaneCore::UI.error("数据源 #{device} 处理失败: #{e.message}")
          # 更新子任务状态
          @task_manager.update_task_state(
            @app["bundle_id"],
            @app["name"],
            task,
            task_name,
            false,
            {
              key: "device",
              value: device,
              success: false,
            }
          )
        end
      end

      # 子任务结束后判断父任务是否已完成
      @task_manager.mark_task_success(@app["bundle_id"], task)
    end

    FastlaneCore::Helper.hide_loading_indicator
  end

  # 数据集-留存率
  def upload_app_analytics_dataset_retention
    task = "upload_app_analytics_dataset_retention"
    task_name = "数据集-留存率"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    if @task_manager.should_process_task?(@app["bundle_id"], task)
      # fail_if_configured(task, "数据集分析")
      @app_analytics_dataset_regions.each do |region|
        unless @task_manager.should_process_subtask?(@app["bundle_id"], task, "region", region)
          FastlaneCore::UI.message("跳过国家地区：#{region}")
          next
        end

        begin
          FastlaneCore::UI.message("处理国家地区：#{region}")
          fail_if_configured(region["storefront_id"], "国家地区#{region}")
          # 更新子任务状态
          @task_manager.update_task_state(
            @app["bundle_id"],
            @app["name"],
            task,
            task_name,
            false,
            {
              key: "region",
              value: region,
              success: true,
            }
          )
        rescue StandardError => e
          FastlaneCore::UI.error("国家地区 #{region} 处理失败: #{e.message}")
          # 更新子任务状态
          @task_manager.update_task_state(
            @app["bundle_id"],
            @app["name"],
            task,
            task_name,
            false,
            {
              key: "region",
              value: region,
              success: false,
            }
          )
        end
      end

      # 子任务结束后判断父任务是否已完成
      @task_manager.mark_task_success(@app["bundle_id"], task)
    end

    FastlaneCore::Helper.hide_loading_indicator
  end

  # Proceeds 方法
  def upload_proceeds
    task = "upload_proceeds"
    task_name = "营收数据"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    begin
      fail_if_configured(task, task_name)
      @task_manager.update_task_state(
        @app["bundle_id"],
        @app["name"],
        task,
        task_name,
        true
      )
    rescue => e
      @task_manager.update_task_state(
        @app["bundle_id"],
        @app["name"],
        task,
        task_name,
        false
      )
      raise e
    end

    FastlaneCore::Helper.hide_loading_indicator
  end

  # App Analytics 上传方法
  def upload_app_analytics
    task = "upload_app_analytics"
    task_name = "应用分析数据"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    begin
      fail_if_configured(task, task_name)
      @task_manager.update_task_state(
        @app["bundle_id"],
        @app["name"],
        task,
        task_name,
        true
      )
    rescue => e
      @task_manager.update_task_state(
        @app["bundle_id"],
        @app["name"],
        task,
        task_name,
        false
      )
      raise e
    end

    FastlaneCore::Helper.hide_loading_indicator
  end

  # Retention 上传方法
  def upload_retention
    task = "upload_retention"
    task_name = "留存率数据"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    begin
      fail_if_configured(task, task_name)
      @task_manager.update_task_state(
        @app["bundle_id"],
        @app["name"],
        task,
        task_name,
        true
      )
    rescue => e
      @task_manager.update_task_state(
        @app["bundle_id"],
        @app["name"],
        task,
        task_name,
        false
      )
      raise e
    end

    FastlaneCore::Helper.hide_loading_indicator
  end

  # Benchmarks 上传方法
  def upload_benchmarks
    task = "upload_benchmarks"
    task_name = "基准数据"

    FastlaneCore::Helper.show_loading_indicator("上报#{task_name}")

    begin
      fail_if_configured(task, task_name)
      @task_manager.update_task_state(
        @app["bundle_id"],
        @app["name"],
        task,
        task_name,
        true
      )
    rescue => e
      @task_manager.update_task_state(
        @app["bundle_id"],
        @app["name"],
        task,
        task_name,
        false
      )
      raise e
    end

    FastlaneCore::Helper.hide_loading_indicator
  end

  private

  def fail_if_configured(task, task_name)
    if @fail_tasks.include?(task.to_s)
      raise StandardError.new("测试模式：#{task_name} 任务失败")
    end
  end
end
