module SharedValues
  @regions = {
    "美国" => "US",
    "丹麦" => "DK",
    "俄罗斯" => "RU",
    "印度尼西亚" => "ID",
    "土耳其" => "TR",
    "希腊" => "GR",
    "德国" => "DE",
    "意大利" => "IT",
    "挪威" => "NO",
    "日本" => "JP",
    "法国" => "FR",
    "泰国" => "TH",
    "瑞典" => "SE",
    "中国" => "CN",
    "中国台湾" => "TW",
    "中国香港" => "HK",
    "芬兰" => "FI",
    "加拿大" => "CA",
    "澳大利亚" => "AU",
    "英国" => "GB",
    "荷兰" => "NL",
    "巴西" => "BR",
    "葡萄牙" => "PT",
    "墨西哥" => "MX",
    "西班牙" => "ES",
    "越南" => "VN",
    "韩国" => "KR",
    "马来西亚" => "MY",
    "沙特" => "SA",
    "以色列" => "IL",
  }

  def self.get_all_regions
    @regions
  end

  def self.get_random_regions(random)
    @regions.to_a.sample(random).to_h.values
  end
end
